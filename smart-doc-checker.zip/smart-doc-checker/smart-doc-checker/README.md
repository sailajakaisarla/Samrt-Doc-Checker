# Smart Doc Checker (Local)

## Overview
Simple local project: Express backend, plain-JS frontend. Upload up to 3 text files, AI/local heuristic compares and generates a report. Includes mock billing and pathway watch.

## Quick start
1. Open a terminal.
2. `cd backend`
3. `npm install`
4. Copy `.env.example` to `.env` and edit if needed.
5. `npm start`
6. Open `http://localhost:4000` in your browser.

## Notes
- Demo accepts `.txt` and `.md` files. Add PDF/DOCX parsing with libraries like `mammoth` and `pdf-parse`.
- To enable real OpenAI, set `OPENAI_API_KEY` in `.env`.
